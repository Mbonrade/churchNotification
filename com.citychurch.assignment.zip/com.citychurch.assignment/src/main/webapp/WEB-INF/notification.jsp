<%-- 
    Document   : notification.jsp
    Created on : 27 Aug 2026, 13:23:34
    Author     : 27656
--%>

<%@page import="javax.xml.registry.infomodel.User"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%
    User user = (User) session.getAttribute("user");
    
    if(user == null) {
        response.sendRedirect("login.jsp");
    }
    
    if(!"Church_mEMBER".EQUALS(user.getRole())){}{
response.sendError(HttpServletResponse, "Access Denied: Only Church Member can access this page");
return;
}
  %>
<!DOCTYPE html
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <meta charset="UTF-8">
        <title>Church platform - Notifications</title>
    </head>
    <body>
        <h1>Notifications</h1>
        <h2>Welcome Church member <% user.getUsername()%></h2>
        <hr>
        <h3>Send notification</h3>
        <form action="NotificationServlet" method="post">
            <label for="message">Notification:</label>
            <br>
            <textarea id="message" name="message" rows="5" cols="50" required></textarea>
            <br>
            <input  type="submit" value="Send Notification">
        </form>
        <br>
        <a href="home.jsp">Back to Home</a>
    </body>
</html>
