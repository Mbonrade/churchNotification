<%-- 
    Document   : home.hsp
    Created on : 27 Aug 2026, 12:37:52
    Author     : 27656
--%>

<%@page import="javax.xml.registry.infomodel.User"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="com.city.church.assignment" %>
<% 
    User user = (User) session.getAttribute("user");
    
    if(user ==null){
        response.sendRedirect("login.jsp");
        return;
    }
    
   %>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Church Platform -Home</title>
    </head>
    <body>
        <h1>Church Platform</h1>
        <h2>Welcome, <%= user.getUsername() %>!</h2>
        <p>Role: <%= user.getRole() %></p>
        <hr>
        <h2>Notification</h2>
        <textarea id="notificationsArea" rows="15" cols="60" readonly> <textarea>
<br><br>
<a href="login.jsp">Notification Management</a>
<br><br>
<a href="-login.jsp">Logout></a>
<script>
    var webSocket  =new WebSocket("ws://localhost:8080/WebSocketPrj01/serverEndPoint");
     var notificationArea = document.getElementById("notificationArea");
     
     webSocket.onopen =function() {
         notificationArea.value += "Connected to notification server...\n"
     };
     
     webSocket.onmessage =function(message) {
         notification.value += "notifications:" + message.data  + "\n";
     };
     webSocket.onclose =function () {
     notificationArea.value += "Disconnected from notification server.\n";
 };
 
 webSokcet.onerror function () {
     "WebSocket error occured.\n";
 };
 </script>
    </body>
</html>
