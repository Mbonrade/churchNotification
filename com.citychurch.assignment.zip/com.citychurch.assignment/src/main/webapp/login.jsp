<%-- 
    Document   : login.jsp
    Created on : 27 Aug 2026, 11:51:45
    Author     : 27656
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Church Platform - Logic</title>
    </head>
    <body>
        <h1>Church Platform</h1>
        <h2>Login</h2>
        
        <form action ="LoginServelet" method="post">
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" required>
            <br>
            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>
            <br>
            <input type="submit" value="Login">
        </form>
        
        <p><h2>Don't have an account<a href="registration.jsp">Register here</h2></a></p>
    </body>
</html>
