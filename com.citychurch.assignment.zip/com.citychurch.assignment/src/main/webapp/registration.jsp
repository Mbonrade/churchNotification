<%-- 
    Document   : registration.jso
    Created on : 27 Aug 2026, 19:42:23
    Author     : 27656
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>Church Platform - Registration</title>
</head>

<body>
    <h1>Church platform</h1>
    <h2>user Registration</h2>
    <form action="RegistrationServlet" method="post">
        <label for="username">Username:</label>
        <input type="text" id="username" name="username" required>
        <br>
        <label for="role">Role:</label>
        
        <select id="role" name="role" required>
            <option value="">Select Role</option>
            <option value="MEMBER">church Member</option>
            <option value="ch">Church Leader</option>
        </select>
        
        <br>
        <input type="submit" value="Register">
    </form>
    <p>Already have an account?
    <a href="login.jsp">Login here</a>
     </p>
</body>  
</html>