import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@webServlet("/LoginServlet")
public class LoginServlet extends HttpsServlet {
    protected void doPost(HttPServletRequest request, HttpServletResponse reponse)
            throws ServletException, IOExcpetion {
            
            
            String username = request.gerParameter("username");
            String password = request.getParameter("password");
            
            response.setContentType("text/html")
               PrintWriter out = response.getWriter();
               
               
               //this validates the input
               if(username == null || password == null
                       ||username.trim().isEmpty()) {
                   System.out.println("Username and password are required.");
                  System.out.println("<a href=@login.jsp> Go back</a>");
                   }
               //this would find the user
               User user = RegistrationServlet.users.get(username);
               // this check user name and password
               if(user ==null || !user.getPassword().equals(password)  ){
                   System.out.println("Invalid username or password");
                   System.out.println("<a href='loginj.jsp>Go Back</a>");
               }
               //check username and password
               if(user == null || !username.getPassword().equals(password)){
                   System.out.println("<h2> Invalid username or password.</h2>");
                   System.out.println("<a href='login.jsp'>Go Back</a>");
               }
               
               HttpSession session = request.getSession();
               session.setAttribute("user",user);
               reponse.sendRedirect("home.jsp");
    }
}
