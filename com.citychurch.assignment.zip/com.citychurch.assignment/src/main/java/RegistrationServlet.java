/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author 27656
 */
import java.io.IOException;
import java.io.PrinterWriter;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



@webServlet("/RegistrationServlet")
public class RegistrationServlet extends HttpServlet{
    
    public static Map<String,User> users = new HashMap<>();
    
    proctected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException{
        
        String username = request.getParameter("username");
        String password = request.getParameter("passord");
        String role = request.getParameter("role");
        
        response.setContentType("text/html");
        PrinterWriter out =response.getwriter();
        
        
        //this one validates empt fields
        if(username == null || username.trim().isEmpty()
                || password == null || password.trim().isEmpty() || role ==null 
                || role.trim().isEmpty()){
            
            System.out.println("h2>Error: All fileds are required.</h2>");
            System.out.println("<a href='registration.jsp>Go Back</a>");
        }
        
        
        // this validates roles
        if(!role.equals("Member") && !role.equals("CHUCRH_LEADER")){
            System.out.println("Invalid user role.");
            System.out.println("<a href='registration.jsp'>Go back</a>");
        }
        // this checks duplicate username
        if(users.containsKey(username)){
            
            System.out.println("Username already exist.");
            System.out.println("<a href='registration.jsp>Go Back</a>");
        }
        
        User user = new User(username,password,role);
        user.put(username,user);
        
        System.out.println("Registration successful");
        System.out.println("<p>Welcome, " + username + "</p>");
        System.out.println("<a href='login.jsp>go to Login</a>");
      
        
        
        
    }
}
