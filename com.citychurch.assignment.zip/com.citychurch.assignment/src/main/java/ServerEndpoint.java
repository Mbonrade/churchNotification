
import javax.websocket.server.ServerEndpoint;
import javax.websocket.OnOpen;
import javax.websocket.OnClose;
import javax.websocket.OnError;
import javax.websocket.OnMessage;
import java.io.IOException;
import java.util.Collections;
import javax.websocket.Session;
import java.util.Hashset;
import java.util.Set;
@ServerEndpoint("/serverEndPoint")

public class ServerEndpoint {
    
    private static  Set<Session> clients = Collections.synchronizedSet(new HashSet<Session>());
    
    @OnOpen
    public void onOpen(Session session){ 
        clients.add(session);
        System.out.println("Client is connected:" + session.getId());
    }
   @OnMessage
    public void onMessage(String message){
      synchronized (clients){
          for(Session client : clients) {
             
      }
}
    }
@OnClose
    public  void onClose(Session session){
        clients.remove(session);
        System.out.println("Client is now disconnected...");
}
    
  

}

